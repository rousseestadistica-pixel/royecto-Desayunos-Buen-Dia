# ==============================================
# 1. CARGA DE LIBRERÍAS
# ==============================================
library(shiny)
library(shinydashboard)
library(DT)
library(plotly)
library(dplyr)
library(readxl)
library(ggplot2)

# ==============================================
# 2. INTERFAZ DE USUARIO (UI)
# ==============================================
ui <- dashboardPage(
  skin = "blue",
  dashboardHeader(title = "StatLab v1.0", titleWidth = 250),
  
  dashboardSidebar(
    width = 250,
    sidebarMenu(
      id = "sidebar",
      menuItem("Carga de Datos", tabName = "data", icon = icon("upload")),
      menuItem("Análisis Exploratorio", tabName = "explore", icon = icon("search")),
      menuItem("Visualización", tabName = "plots", icon = icon("chart-line")), # NUEVA
      menuItem("Estadística Descriptiva", tabName = "descriptive", icon = icon("chart-bar")),
      menuItem("Pruebas de Hipótesis", tabName = "hypothesis", icon = icon("check-double")),
      menuItem("Modelado", tabName = "modeling", icon = icon("project-diagram"))
    )
  ),
  
  dashboardBody(
    tabItems(
      # TAB CARGA
      tabItem(tabName = "data",
              fluidRow(
                box(title = "Carga de Archivo", width = 4, status = "primary",
                    fileInput("file", "Subir archivo (.csv, .xlsx)", accept = c(".csv", ".xlsx")),
                    selectInput("sep", "Separador (Solo CSV)", choices = c("Coma" = ",", "Punto y Coma" = ";", "Tab" = "\t")),
                    checkboxInput("header", "Encabezado", TRUE)),
                valueBoxOutput("row_count", width = 2),
                valueBoxOutput("col_count", width = 2),
                valueBoxOutput("mem_size", width = 4)
              ),
              box(title = "Vista Previa", width = 12, DTOutput("data_preview"))
      ),
      
      # TAB EXPLORAR
      tabItem(tabName = "explore",
              box(title = "Estructura Técnica", width = 12, verbatimTextOutput("data_structure"))
      ),
      
      # TAB VISUALIZACIÓN (ADAPTADA CON TUS GRÁFICOS)
      tabItem(tabName = "plots",
              fluidRow(
                box(title = "Configuración del Gráfico", width = 4, status = "warning",
                    selectInput("plot_type", "Tipo de Gráfico:", 
                                choices = c("Cajas (Boxplot)" = "box", 
                                            "Dispersión (Tendencia)" = "scatter", 
                                            "Barras (Frecuencia)" = "bar")),
                    selectInput("var_x", "Variable X (Categoría/Eje X):", choices = NULL),
                    selectInput("var_y", "Variable Y (Numérica):", choices = NULL),
                    selectInput("var_col", "Color por (Factor):", choices = NULL),
                    actionButton("gen_plot", "Generar Gráfico", class = "btn-block btn-warning")
                ),
                box(title = "Resultado Visual", width = 8, status = "primary",
                    plotOutput("custom_plot", height = "500px"))
              )
      ),
      
      # TAB DESCRIPTIVA
      tabItem(tabName = "descriptive",
              box(width = 12, 
                  selectInput("desc_var", "Variables a analizar:", choices = NULL, multiple = TRUE),
                  actionButton("run_desc", "Calcular Estadísticas", class = "btn-primary"),
                  hr(),
                  DTOutput("descriptive_table"))
      ),
      
      # TAB HIPÓTESIS
      tabItem(tabName = "hypothesis",
              box(width = 12,
                  selectInput("t_var1", "Variable A:", choices = NULL),
                  selectInput("t_var2", "Variable B:", choices = NULL),
                  actionButton("run_ttest", "Ejecutar Prueba t", class = "btn-warning"),
                  hr(),
                  verbatimTextOutput("ttest_results"))
      ),
      
      # TAB MODELADO
      tabItem(tabName = "modeling",
              box(title = "Regresión Lineal", status = "primary", solidHeader = TRUE, width = 12,
                  selectInput("lm_dep", "Y (Dependiente):", choices = NULL),
                  selectInput("lm_indep", "X (Independientes):", choices = NULL, multiple = TRUE),
                  actionButton("run_lm", "Ajustar Modelo", class = "btn-success"),
                  hr(),
                  tabsetPanel(
                    tabPanel("Resumen", verbatimTextOutput("lm_summary")),
                    tabPanel("Diagnóstico", plotOutput("lm_diagnostics")),
                    tabPanel("Coeficientes", DTOutput("lm_coeff"))
                  )
              )
      )
    )
  )
)

# ==============================================
# 3. SERVIDOR (LÓGICA)
# ==============================================
server <- function(input, output, session) {
  
  data_loaded <- reactiveVal(NULL)
  
  observeEvent(input$file, {
    req(input$file)
    ext <- tools::file_ext(input$file$name)
    
    df <- tryCatch({
      if (ext == "csv") {
        read.csv(input$file$datapath, sep = input$sep, header = input$header, stringsAsFactors = TRUE)
      } else if (ext %in% c("xls", "xlsx")) {
        read_excel(input$file$datapath)
      }
    }, error = function(e) {
      showNotification("Error al leer el archivo", type = "error")
      return(NULL)
    })
    
    if(!is.null(df)) {
      data_loaded(as.data.frame(df))
      vars <- names(df)
      num_vars <- names(df)[sapply(df, is.numeric)]
      cat_vars <- names(df)[sapply(df, function(x) is.factor(x) | is.character(x))]
      
      # Actualizar selectores
      updateSelectInput(session, "var_x", choices = vars)
      updateSelectInput(session, "var_y", choices = num_vars)
      updateSelectInput(session, "var_col", choices = c("Ninguno" = "", cat_vars))
      updateSelectInput(session, "desc_var", choices = num_vars)
      updateSelectInput(session, "t_var1", choices = num_vars)
      updateSelectInput(session, "t_var2", choices = num_vars)
      updateSelectInput(session, "lm_dep", choices = num_vars)
      updateSelectInput(session, "lm_indep", choices = vars)
    }
  })
  
  # Lógica del Gráfico Adaptado
  output$custom_plot <- renderPlot({
    req(input$gen_plot, data_loaded())
    df <- data_loaded()
    
    p <- ggplot(df, aes_string(x = input$var_x))
    
    if(input$plot_type == "box") {
      p <- p + geom_boxplot(aes_string(y = input$var_y, fill = input$var_x))
    } else if(input$plot_type == "scatter") {
      p <- ggplot(df, aes_string(x = input$var_x, y = input$var_y)) + 
        geom_point(aes_string(color = if(input$var_col=="") NULL else input$var_col)) +
        geom_smooth(method = "lm")
    } else if(input$plot_type == "bar") {
      p <- p + geom_bar(aes_string(fill = input$var_x)) + coord_flip()
    }
    
    p + theme_minimal() + labs(title = "Gráfico Generado por StatLab")
  })
  
  # Resto de salidas originales (Simplificadas para brevedad)
  output$data_preview <- renderDT({ req(data_loaded()); datatable(head(data_loaded(), 20), options = list(scrollX = TRUE)) })
  output$row_count <- renderValueBox({ valueBox(nrow(data_loaded()), "Filas", icon = icon("table")) })
  output$col_count <- renderValueBox({ valueBox(ncol(data_loaded()), "Columnas", icon = icon("columns")) })
  output$mem_size <- renderValueBox({ valueBox(paste(round(object.size(data_loaded())/1024^2, 2), "MB"), "Memoria", color = "yellow") })
  output$data_structure <- renderPrint({ req(data_loaded()); str(data_loaded()) })
  
  output$descriptive_table <- renderDT({
    req(input$run_desc); df_desc <- data_loaded()[, input$desc_var, drop = FALSE]
    datatable(as.data.frame(do.call(cbind, lapply(df_desc, summary))))
  })
  
  output$ttest_results <- renderPrint({
    req(input$run_ttest); t.test(data_loaded()[[input$t_var1]], data_loaded()[[input$t_var2]])
  })
  
  lm_model <- eventReactive(input$run_lm, {
    req(input$lm_dep, input$lm_indep)
    formula <- as.formula(paste(input$lm_dep, "~", paste(input$lm_indep, collapse = "+")))
    lm(formula, data = data_loaded())
  })
  
  output$lm_summary <- renderPrint({ req(lm_model()); summary(lm_model()) })
  output$lm_diagnostics <- renderPlot({ req(lm_model()); par(mfrow=c(2,2)); plot(lm_model()) })
  output$lm_coeff <- renderDT({ req(lm_model()); datatable(as.data.frame(summary(lm_model())$coefficients)) })
}

# ==============================================
# 4. LANZAR APP
# ==============================================
shinyApp(ui = ui, server = server)